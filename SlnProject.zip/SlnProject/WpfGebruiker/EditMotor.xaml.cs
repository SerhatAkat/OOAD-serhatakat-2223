﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using MyClassLibrary;
using static MyClassLibrary.Voertuig;

namespace WpfGebruiker
{
    /// <summary>
    /// Interaction logic for EditMotor.xaml
    /// </summary>
    public partial class EditMotor : Window
    {
        private Voertuig teBewerkenVoertuig;
        private Gebruiker currentId;
        private List<Foto> fotosTeVerwijderen = new List<Foto>();


        public EditMotor(Gebruiker userId)
        {
            InitializeComponent();
            currentId = userId;
            btnUploaden.Click += BtnUploaden_Click;
        }
        public EditMotor(Voertuig voertuig)
        {
            teBewerkenVoertuig = voertuig;

            InitializeComponent();

            txtNaam.Text = voertuig.Naam;
            txtMerk.Text = voertuig.Merk;
            txtModel.Text = voertuig.Model;
            txtBeschrijving.Text = voertuig.Beschrijving;
            if (voertuig.BrandstofType.HasValue)
                cbxBrandstof.SelectedIndex = (int)voertuig.BrandstofType;
            else
                cbxBrandstof.SelectedIndex = -1;

            if (voertuig.TransmissieType.HasValue)
                cbxTransmissie.SelectedIndex = (int)voertuig.TransmissieType;
            else
                cbxTransmissie.SelectedIndex = -1;

            txtBouwjaar.Text = voertuig.Bouwjaar.ToString();

            // Haal de afbeeldingen op voor dit voertuig
            List<Foto> fotos = Foto.GetFotosForVoertuig(voertuig.Id);



            if (fotos.Count >= 1)
            {
                Foto afb1 = fotos[0];
                btnVerwijder1.Tag = afb1;
            }
            if (fotos.Count >= 2)
            {
                Foto afb2 = fotos[1];
                btnVerwijder2.Tag = afb2;
            }
            if (fotos.Count >= 3)
            {
                Foto afb3 = fotos[2];
                btnVerwijder3.Tag = afb3;
            }

            // Zet de byte-arrays om in afbeeldingen en stel de bron van de afbeeldingscontrols in
            for (int i = 0; i < fotos.Count; i++)
            {
                byte[] afbeeldingData = fotos[i].Image;
                BitmapImage bitmap = new BitmapImage();

                using (var stream = new MemoryStream(afbeeldingData))
                {
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.StreamSource = stream;
                    bitmap.EndInit();
                }

                // Maak een nieuwe instantie van BitmapImage en kopieer de afbeeldingsgegevens
                BitmapImage imageCopy = new BitmapImage();
                imageCopy.BeginInit();
                imageCopy.CacheOption = BitmapCacheOption.OnLoad;
                imageCopy.StreamSource = new MemoryStream(afbeeldingData);  // Kopieer de gegevens naar de nieuwe instantie
                imageCopy.EndInit();

                switch (i)
                {
                    case 0:
                        img1.Source = imageCopy;
                        break;
                    case 1:
                        img2.Source = imageCopy;
                        break;
                    case 2:
                        img3.Source = imageCopy;
                        break;
                }
            }

            currentId = new Gebruiker { Id = voertuig.Id };
        }

        private void UpdateImages()
        {
            List<Foto> fotos = Foto.GetFotosForVoertuig(teBewerkenVoertuig.Id);

            if (fotos.Count >= 1)
            {
                SetImageSource(fotos[0], img1);
            }
            else
            {
                img1.Source = null;
            }

            if (fotos.Count >= 2)
            {
                SetImageSource(fotos[1], img2);
            }
            else
            {
                img2.Source = null;
            }

            if (fotos.Count >= 3)
            {
                SetImageSource(fotos[2], img3);
            }
            else
            {
                img3.Source = null;
            }
            if (fotos.Count < 3)
            {
                img3.Source = null;
            }
            else if (fotos.Count == 2)
            {
                img3.Source = null;
            }
        }

        private void SetImageSource(Foto foto, Image img)
        {
            byte[] afbeeldingData = foto.Image;
            BitmapImage bitmap = new BitmapImage();

            using (var stream = new MemoryStream(afbeeldingData))
            {
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = stream;
                bitmap.EndInit();
            }

            // Maak een nieuwe instantie van BitmapImage en kopieer de afbeeldingsgegevens
            BitmapImage imageCopy = new BitmapImage();
            imageCopy.BeginInit();
            imageCopy.CacheOption = BitmapCacheOption.OnLoad;
            imageCopy.StreamSource = new MemoryStream(afbeeldingData);  // Kopieer de gegevens naar de nieuwe instantie
            imageCopy.EndInit();

            img.Source = imageCopy;
        }

        private void BtnUploaden_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "Image files (*.jpg, *.png) | *.jpg; *.png";

            if (openFileDialog.ShowDialog() == true)
            {
                List<BitmapImage> images = new List<BitmapImage>();
                foreach (string filename in openFileDialog.FileNames)
                {
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(filename);
                    bitmap.EndInit();
                    images.Add(bitmap);
                }
                if (images.Count > 0)
                {
                    for (int i = 0; i < images.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                img1.Source = images[i];
                                break;
                            case 1:
                                img2.Source = images[i];
                                break;
                            case 2:
                                img3.Source = images[i];
                                break;
                            default:
                                MessageBox.Show("Er kunnen maximaal 3 foto's worden geupload", "Fout", MessageBoxButton.OK, MessageBoxImage.Error);
                                return;
                        }

                        // Maak een nieuwe Foto-object en voeg het toe aan de database
                        Foto foto = new Foto();
                        foto.AddFoto(ImageToByteArray(images[i]), teBewerkenVoertuig.Id);
                    }

                    // Opnieuw ophalen van de teBewerkenVoertuig-instantie
                    teBewerkenVoertuig = GetVoertuigById(teBewerkenVoertuig.Id);
                }
            }
        }


        private byte[] ImageToByteArray(BitmapImage image)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                encoder.Save(stream);
                return stream.ToArray();
            }
        }

        private void VerwijderAfbeelding_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Foto foto = button.Tag as Foto;

            switch (button.Name)
            {
                case "btnVerwijder1":
                    img1.Source = null;
                    if (foto != null) fotosTeVerwijderen.Add(foto);
                    break;
                case "btnVerwijder2":
                    img2.Source = null;
                    if (foto != null) fotosTeVerwijderen.Add(foto);
                    break;
                case "btnVerwijder3":
                    img3.Source = null;
                    if (foto != null) fotosTeVerwijderen.Add(foto);
                    break;
            }
        }

        private void btnAnnuleren_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnOpslaan_Click(object sender, RoutedEventArgs e)
        {
            List<Foto> bestaandeFotos = Foto.GetFotosForVoertuig(teBewerkenVoertuig.Id);
            int index = 0;
            // Reset error labels
            lblNaamError.Content = "";
            lblBeschrijvingError.Content = "";
            lblBouwjaarError.Content = "";

            bool isValid = true;

            foreach (Foto foto in fotosTeVerwijderen)
            {
                Foto.VerwijderFotoByFotoId(foto.Id);
            }

            // Validatie
            if (string.IsNullOrEmpty(txtNaam.Text))
            {
                lblNaamError.Content = "Gelieve een naam te geven.";
                isValid = false;
            }
            if (string.IsNullOrEmpty(txtBeschrijving.Text))
            {
                lblBeschrijvingError.Content = "Gelieve een beschrijving te geven.";
                isValid = false;
            }
            if (string.IsNullOrEmpty(txtBouwjaar.Text))
            {
                lblBouwjaarError.Content = "Gelieve een bouwjaar in te vullen.";
                isValid = false;
            }

            if (img1.Source == null && img2.Source == null && img3.Source == null)
            {
                lblImageError.Content = "Gelieve ten minste 1 afbeelding te kiezen";
                isValid = false;
            }

            // Voer de rest van de methode alleen uit als alle velden zijn gevalideerd
            if (isValid)
            {
                Voertuig nieuwVoertuig = new Voertuig
                {
                    Naam = txtNaam.Text,
                    Merk = txtMerk.Text,
                    Model = txtModel.Text,
                    Beschrijving = txtBeschrijving.Text,
                    TransmissieType = (Transmissie?)cbxTransmissie.SelectedIndex,
                    BrandstofType = (Brandstof?)cbxBrandstof.SelectedIndex
                };

                if (!int.TryParse(txtBouwjaar.Text, out int bouwjaar))
                {
                    MessageBox.Show("Vul een geldig bouwjaar in.", "Fout", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                nieuwVoertuig.Bouwjaar = bouwjaar;

                nieuwVoertuig.UpdateGemotoriseerd();

                Foto foto = new Foto();

                foreach (Image img in new[] { img1, img2, img3 })
                {
                    if (img.Source != null)
                    {
                        var encoder = new PngBitmapEncoder();
                        encoder.Frames.Add(BitmapFrame.Create((BitmapSource)img.Source));

                        using (var stream = new MemoryStream())
                        {
                            encoder.Save(stream);
                            byte[] imgData = stream.ToArray();

                            // Controleer of er een bestaande foto is
                            Foto bestaandeFoto = bestaandeFotos.ElementAtOrDefault(index);
                            if (bestaandeFoto != null)
                            {
                                // Als er een bestaande foto is, bewerk deze dan
                                bestaandeFoto.EditFoto(bestaandeFoto.Id, imgData);
                            }
                            else
                            {
                                // Als er geen bestaande foto is, voeg dan een nieuwe toe
                                foto.AddFoto(imgData, teBewerkenVoertuig.Id);
                            }
                        }
                    }

                    index++;
                }
                VoertuigenPage.Instance.UpdateVoertuigen();
                UpdateImages();
                Close();
            }
        }
    }
}
